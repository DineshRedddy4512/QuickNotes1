package com.example.quicknotes;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Spinner;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.util.ArrayList;
import java.util.List;

public class HomeActivity extends AppCompatActivity {

    private RecyclerView notesRecyclerView;
    private NotesAdapter notesAdapter;
    private List<Note> notesList;
    private Spinner categoryFilterSpinner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        // Initialize views
        notesRecyclerView = findViewById(R.id.notes_recycler_view);
        categoryFilterSpinner = findViewById(R.id.category_filter_spinner);
        FloatingActionButton addNoteButton = findViewById(R.id.add_note_button);

        // Initialize the RecyclerView
        notesList = new ArrayList<>();
        notesAdapter = new NotesAdapter(notesList, this);
        notesRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        notesRecyclerView.setAdapter(notesAdapter);

        // Load notes from the database
        loadNotes();

        // Set up category filter spinner
        categoryFilterSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selectedCategory = parent.getItemAtPosition(position).toString();
                filterNotes(selectedCategory);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Do nothing
            }
        });

        // Add Note button action
        addNoteButton.setOnClickListener(v -> {
            Intent intent = new Intent(HomeActivity.this, NoteCreationActivity.class);
            startActivity(intent);
        });
    }

    private void loadNotes() {
        // Load all notes from the database and update the RecyclerView
        NotesDatabaseHelper dbHelper = new NotesDatabaseHelper(this);
        notesList.clear();
        notesList.addAll(dbHelper.getAllNotes()); // Assumes `getAllNotes()` method returns a List<Note>
        notesAdapter.notifyDataSetChanged();
    }

    private void filterNotes(String category) {
        // Implement filtering based on selected category
        NotesDatabaseHelper dbHelper = new NotesDatabaseHelper(this);
        notesList.clear();
        if (category.equals("All")) {
            notesList.addAll(dbHelper.getAllNotes());
        } else {
            notesList.addAll(dbHelper.getNotesByCategory(category)); // Get notes by selected category
        }
        notesAdapter.notifyDataSetChanged();
    }
}
