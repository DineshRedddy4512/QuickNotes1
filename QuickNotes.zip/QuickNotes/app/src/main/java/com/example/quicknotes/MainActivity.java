package com.example.quicknotes;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Redirect to HomeActivity after setup
        Intent intent = new Intent(MainActivity.this, HomeActivity.class);
        startActivity(intent);

        // Close MainActivity so it's not part of the back stack
        finish();
    }
}
