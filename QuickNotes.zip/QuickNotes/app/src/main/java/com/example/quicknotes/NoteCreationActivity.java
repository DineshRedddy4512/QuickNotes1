package com.example.quicknotes;


import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import androidx.appcompat.app.AppCompatActivity;

public class NoteCreationActivity extends AppCompatActivity {
    private EditText titleEditText, contentEditText;
    private Spinner categorySpinner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_note_creation);

        titleEditText = findViewById(R.id.note_title);
        contentEditText = findViewById(R.id.note_content);
        categorySpinner = findViewById(R.id.note_category);
        Button saveButton = findViewById(R.id.save_note_button);

        saveButton.setOnClickListener(v -> saveNote());
    }

    private void saveNote() {
        // Implement saving note to SQLite
        // e.g., String title = titleEditText.getText().toString();
    }
}
